import os
os.system("start assets/index.html") # opens index.html
os.system("python assets/server.py") # starts the server