import os
import subprocess
import signal

subprocess.Popen(["python", "server.py"]) # start the server
os.system("start index.html") # opens index.html
