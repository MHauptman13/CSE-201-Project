# imports for server specifically
from flask import Flask, request, jsonify
from flask_cors import CORS

# declaring server
app = Flask(__name__)
CORS(app)

# other imports
import yfinance

# setting the route for getstockprice so that index.html can use it
@app.route("/getstockprice", methods=["POST"])
def getstockprice():
    # getting data from index.html
    data = request.get_json()
    try:
        stock = yfinance.Ticker(data.get("ticker")) # gets stock data into 'stock'
        return jsonify({"price": stock.info["currentPrice"]}) # returns the currentPrice value of stock
    except:
        # returns -1 if an invalid stock is sent
        return jsonify({"price": -1})

if __name__ == "__main__":
    app.run(debug=True)
